import {combineReducers} from 'redux';
import getRestaurantDataReducer from './getRestaurantDataReducer.js';


export default combineReducers({
	getRestaurantDataReducer
});