from django.conf.urls import url
from . import views

urlpatterns = [
	url(r'^$', views.index, name='index'),
	url(r'^api/getPerson/$', views.apicall, name='index'),
	url(r'^api/getBankData/$', views.getBankData, name="something")
]